$('#formulario').submit(function(){
	$('#tasks').append('<div><b>'+$('#addtask').val()+'</b></div>');
	$('#addtask').val('');

	return false;
});

$('#addtask').focus(function(){
	
	$('#add').fadeIn('slow');
});

$('#addtask').blur(function(){
	$(this).val('');
	$('#add').fadeOut('slow');
})